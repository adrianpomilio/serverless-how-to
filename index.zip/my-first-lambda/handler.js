'use strict';

exports.handler.myFirstLambda = (event, context, callback) => {
    callback('{message:"my first lambda"}', event);
};
